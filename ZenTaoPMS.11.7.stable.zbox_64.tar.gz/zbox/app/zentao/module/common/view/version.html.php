<?php
js::import($jsRoot . 'version.js');
