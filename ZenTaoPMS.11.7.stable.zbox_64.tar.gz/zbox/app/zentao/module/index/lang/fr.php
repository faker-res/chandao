<?php
$lang->index->common = 'Accueil';
$lang->index->index  = 'Accueil';
