<?php
$lang->index->common = 'Home';
$lang->index->index  = 'Home';
