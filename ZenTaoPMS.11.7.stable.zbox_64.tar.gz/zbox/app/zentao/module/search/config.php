<?php
$config->search = new stdclass();
$config->search->groupItems = 3;
